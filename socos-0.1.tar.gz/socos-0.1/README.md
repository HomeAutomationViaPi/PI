socos
=====

socos (Sonos Controller Shell) is a commandline tool for controlling Sonos
speakers.

Build
=====
[![Build
Status](https://travis-ci.org/SoCo/socos.svg?branch=master)](https://travis-ci.org/SoCo/socos)

[![Requirements Status](https://requires.io/github/SoCo/socos/requirements.png?branch=master)](https://requires.io/github/SoCo/socos/requirements/?branch=master)
